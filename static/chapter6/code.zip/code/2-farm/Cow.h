#pragma once

#include <iostream>

class Cow
{
public:
    void sing() const { std::cout << "Mewwwwwh" << std::endl; }
};
