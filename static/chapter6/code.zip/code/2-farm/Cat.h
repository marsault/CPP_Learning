#pragma once

#include <iostream>

class Cat
{
public:
    void sing() const { std::cout << "Meow" << std::endl; }
};
