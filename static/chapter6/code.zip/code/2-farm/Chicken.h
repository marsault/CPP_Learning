#pragma once

#include <iostream>

class Chicken
{
public:
    void sing() const { std::cout << "Cotcotcotcodet" << std::endl; }
};
