#pragma once

#include <iostream>

class Animal
{
public:
    void sing() const { std::cout << "..." << std::endl; }
};
