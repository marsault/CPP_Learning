#pragma once

#include <iostream>

class Dog
{
public:
    void sing() const { std::cout << "Waf" << std::endl; }
};
