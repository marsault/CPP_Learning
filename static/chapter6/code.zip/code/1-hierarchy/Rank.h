#pragma once

enum class Rank
{
    TopManagement,
    Default,
    Slave,
};
