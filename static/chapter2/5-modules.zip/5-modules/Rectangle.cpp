// Implement Rectangle functions here.
