#include "Rectangle.hpp"

#include <iostream>

int main() {
  Rectangle rect(2.f, 4.f);
  std::cout << "{ L: " << rect.get_length() << ", W: " << rect.get_width()
            << " }" << std::endl;

  rect.scale(3);
  std::cout << "{ L: " << rect.get_length() << ", W: " << rect.get_width()
            << " }" << std::endl;

  return 0;
}
