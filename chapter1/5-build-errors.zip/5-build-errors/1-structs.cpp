struct A
{
    int a = 0;
}

struct B
{
    int b = 0;
}

int add(A a, B b)
{
    return a.a + b.b;
}
