class A
{
    int a = 0;
};

int get_a(A a)
{
    return a.a;
}
