#pragma once

#include "5-tac.hpp"

struct Tic
{
    // Invert value with tac.
    void swap(Tac& tac);

    int value = 0;
};
