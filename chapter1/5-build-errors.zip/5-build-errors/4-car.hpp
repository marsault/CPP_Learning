#include <string>

struct Car
{
    std::string brand;
};
