#include <iostream>

int mani()
{
    std::cout << "Hello world!" << std::endl;
    return 0;
}