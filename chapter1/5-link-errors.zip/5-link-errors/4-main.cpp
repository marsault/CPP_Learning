#include "4-add.hpp"
#include "4-sub.hpp"

int main()
{
    return sub(add(2, 3), add(-2, 9));
}
