#pragma once

int sub(int a, int b);
