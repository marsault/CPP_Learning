#include "3-sub.hpp"

float sub(float a, float b)
{
    return a - b;
}
