#include "3-sub.hpp"

int main()
{
    return sub(1, 2);
}
