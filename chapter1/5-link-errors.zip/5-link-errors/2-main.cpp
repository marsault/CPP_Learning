#include "2-add.hpp"

int main()
{
    return add(1, 2);
}
